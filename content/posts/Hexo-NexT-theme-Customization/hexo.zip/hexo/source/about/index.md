---
title: 关于我
date: 2020-04-05 18:00:21
comments: false
reward_settings:
  enable: false
mathjax: true
---

{% cq %}
<center>$$e^{ iπ }+1=0$$</center>
<p style="text-align:right; font-style:italic;">Euler's formula</p>
<center>Wir müssen wissen. Wir werden wissen.</center>
<center>我们必须知道，我们必将知道！</center>
<p style="text-align:right; font-style:italic;">大卫·希尔伯特(David Hilbert)</p>
{% endcq %}

{% note primary %}

#### 基础信息
- 学生
- 热爱生活 热爱科技
- Github：<https://github.com/st1020>
- Wikidot：<http://st1020.wikidot.com>

{% endnote %}

{% note info %}

#### 专业知识

- Python
- Learning...


{% endnote %}

{% note warning %}

#### 兴趣爱好

- 编程
- 摄影
- 阅读
- 动漫
- 科幻


{% endnote %}

{% note success %}
#### 完成项目
- [Stone Termux管理工具 (Stone-Termux-Tool)](https://github.com/st1020/Stone-Termux-Tool)
- [Termux-Arch](https://github.com/st1020/Termux-Arch)
- [Lcmt (A Linux Container Manager On Termux)](https://github.com/st1020/Lcmt)
- Doing...

{% endnote %}